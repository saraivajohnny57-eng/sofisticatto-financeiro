-- ============================================================
-- V16.8 — AGENDAMENTO AUTOMÁTICO DE COLETA RODONAVES
-- ============================================================

alter table public.coleta_agendamentos
  add column if not exists protocolo_cotacao text,
  add column if not exists valor_frete_negociado numeric(15,2),
  add column if not exists codigo_coleta text,
  add column if not exists data_programada timestamptz,
  add column if not exists servico_api integer,
  add column if not exists status_api text,
  add column if not exists resposta_api jsonb,
  add column if not exists consulta_api jsonb,
  add column if not exists solicitado_api_em timestamptz,
  add column if not exists consultado_api_em timestamptz;

create index if not exists idx_coleta_agendamentos_protocolo
  on public.coleta_agendamentos(protocolo_cotacao);

create index if not exists idx_coleta_agendamentos_codigo
  on public.coleta_agendamentos(codigo_coleta);

-- Mantém compatibilidade com os status anteriores.
alter table public.coleta_agendamentos
  drop constraint if exists coleta_agendamentos_status_check;

alter table public.coleta_agendamentos
  add constraint coleta_agendamentos_status_check
  check (status in (
    'rascunho','solicitado','confirmado','em_coleta',
    'coletado','cancelado','erro'
  ));

select 'V16.8: agendamento automático Rodonaves configurado.' as resultado;
