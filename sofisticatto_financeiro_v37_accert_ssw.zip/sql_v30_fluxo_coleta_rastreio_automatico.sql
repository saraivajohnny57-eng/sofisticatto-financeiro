-- ============================================================
-- V30 — FLUXO AUTOMÁTICO COLETA -> SAÍDAS EM TRÂNSITO
-- ============================================================

alter table public.logistica_rastreamentos
  add column if not exists coleta_agendamento_id uuid
    references public.coleta_agendamentos(id) on delete set null,
  add column if not exists origem text;

create unique index if not exists uq_logistica_rastreamentos_coleta
  on public.logistica_rastreamentos(coleta_agendamento_id)
  where coleta_agendamento_id is not null;

create or replace function public.fn_coleta_para_rastreamento()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_status text;
  v_numero_nfe text;
  v_chave_nfe text;
  v_numero_cte text;
begin
  v_status := lower(coalesce(new.status_api,new.status,''));
  if v_status not in ('coletado','coletada') then
    return new;
  end if;

  v_numero_nfe := coalesce(
    nullif(trim(new.numero_nf),''),
    nullif(trim(new.dados->>'numero_nf'),''),
    nullif(trim(new.dados->>'numero_nfe'),'')
  );
  v_chave_nfe := coalesce(
    nullif(trim(new.dados->>'chave_nfe'),''),
    nullif(trim(new.dados->>'chave_nf'),'')
  );
  v_numero_cte := nullif(trim(new.dados->>'numero_cte'),'');

  insert into public.logistica_rastreamentos(
    sentido,parceiro_nome,transportadora_id,numero_nfe,chave_nfe,numero_cte,
    protocolo_rastreio,data_postagem,volumes,status,observacao,
    coleta_agendamento_id,origem,atualizado_em,atualizado_por
  )
  values(
    'saida',coalesce(new.cliente_nome,'Cliente'),new.transportadora_id,
    v_numero_nfe,v_chave_nfe,v_numero_cte,nullif(trim(new.protocolo_cotacao),''),
    coalesce(new.coletado_em::date,new.data_programada::date,current_date),
    new.volumes,'em_transito',
    'Criado automaticamente quando a coleta foi marcada como coletada.',
    new.id,'coleta_agendamento',now(),'trigger_v30'
  )
  on conflict (coleta_agendamento_id)
    where coleta_agendamento_id is not null
  do update set
    parceiro_nome=excluded.parceiro_nome,
    transportadora_id=excluded.transportadora_id,
    numero_nfe=coalesce(excluded.numero_nfe,public.logistica_rastreamentos.numero_nfe),
    chave_nfe=coalesce(excluded.chave_nfe,public.logistica_rastreamentos.chave_nfe),
    numero_cte=coalesce(excluded.numero_cte,public.logistica_rastreamentos.numero_cte),
    protocolo_rastreio=coalesce(excluded.protocolo_rastreio,public.logistica_rastreamentos.protocolo_rastreio),
    data_postagem=coalesce(excluded.data_postagem,public.logistica_rastreamentos.data_postagem),
    volumes=coalesce(excluded.volumes,public.logistica_rastreamentos.volumes),
    status=case
      when public.logistica_rastreamentos.status in ('entregue','recebido','cancelado')
        then public.logistica_rastreamentos.status
      else 'em_transito'
    end,
    atualizado_em=now();

  return new;
end;
$$;

drop trigger if exists trg_coleta_para_rastreamento on public.coleta_agendamentos;
create trigger trg_coleta_para_rastreamento
after insert or update of status,status_api,coletado_em
on public.coleta_agendamentos
for each row
execute function public.fn_coleta_para_rastreamento();

-- Coletas antigas já coletadas entram automaticamente em Saídas em trânsito.
insert into public.logistica_rastreamentos(
  sentido,parceiro_nome,transportadora_id,numero_nfe,chave_nfe,numero_cte,
  protocolo_rastreio,data_postagem,volumes,status,observacao,
  coleta_agendamento_id,origem,atualizado_em,atualizado_por
)
select
  'saida',c.cliente_nome,c.transportadora_id,
  coalesce(nullif(trim(c.numero_nf),''),nullif(trim(c.dados->>'numero_nf'),''),nullif(trim(c.dados->>'numero_nfe'),'')),
  coalesce(nullif(trim(c.dados->>'chave_nfe'),''),nullif(trim(c.dados->>'chave_nf'),'')),
  nullif(trim(c.dados->>'numero_cte'),''),
  nullif(trim(c.protocolo_cotacao),''),
  coalesce(c.coletado_em::date,c.data_programada::date,c.created_at::date),
  c.volumes,'em_transito',
  'Backfill V30: coleta já registrada como coletada.',
  c.id,'coleta_agendamento',now(),'migracao_v30'
from public.coleta_agendamentos c
where lower(coalesce(c.status_api,c.status,'')) in ('coletado','coletada')
  and not exists (
    select 1 from public.logistica_rastreamentos r
    where r.coleta_agendamento_id=c.id
  );

-- Rodonaves aberta: entra em monitoramento por protocolo/NF antes da coleta.
insert into public.logistica_rastreamentos(
  sentido,parceiro_nome,transportadora_id,numero_nfe,chave_nfe,numero_cte,
  protocolo_rastreio,data_postagem,volumes,status,observacao,
  coleta_agendamento_id,origem,atualizado_em,atualizado_por
)
select
  'saida',c.cliente_nome,c.transportadora_id,
  coalesce(nullif(trim(c.numero_nf),''),nullif(trim(c.dados->>'numero_nf'),''),nullif(trim(c.dados->>'numero_nfe'),'')),
  coalesce(nullif(trim(c.dados->>'chave_nfe'),''),nullif(trim(c.dados->>'chave_nf'),'')),
  nullif(trim(c.dados->>'numero_cte'),''),
  nullif(trim(c.protocolo_cotacao),''),
  c.data_programada::date,c.volumes,'aguardando_coleta',
  'V30: monitoramento automático Rodonaves por protocolo/NF.',
  c.id,'coleta_agendamento',now(),'migracao_v30'
from public.coleta_agendamentos c
join public.frete_transportadoras t on t.id=c.transportadora_id
where t.nome ilike '%Rodonaves%'
  and lower(coalesce(c.status_api,c.status,'')) not in ('cancelado','coletado','coletada')
  and (
    nullif(trim(c.protocolo_cotacao),'') is not null
    or nullif(trim(c.numero_nf),'') is not null
    or nullif(trim(c.dados->>'numero_nf'),'') is not null
  )
  and not exists (
    select 1 from public.logistica_rastreamentos r
    where r.coleta_agendamento_id=c.id
  );

select
  'V30 instalada' as resultado,
  count(*) filter (where coleta_agendamento_id is not null) as rastreios_vinculados
from public.logistica_rastreamentos;
