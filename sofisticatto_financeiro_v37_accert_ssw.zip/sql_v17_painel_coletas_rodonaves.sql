-- ============================================================
-- V17 — PAINEL OPERACIONAL DE COLETAS RODONAVES
-- ============================================================
alter table public.coleta_agendamentos
  add column if not exists cancelamento_motivo text,
  add column if not exists cancelamento_solicitado_em timestamptz,
  add column if not exists cancelamento_solicitado_por text;

alter table public.coleta_agendamentos drop constraint if exists coleta_agendamentos_status_check;
alter table public.coleta_agendamentos add constraint coleta_agendamentos_status_check
check (status in ('rascunho','solicitado','em_aberto','confirmado','em_coleta','coletado','cancelamento_solicitado','cancelado','erro'));

create table if not exists public.coleta_status_eventos (
  id uuid primary key default gen_random_uuid(),
  agendamento_id uuid not null references public.coleta_agendamentos(id) on delete cascade,
  status_anterior text,
  status_novo text,
  origem text not null default 'sistema',
  detalhes jsonb,
  usuario text,
  created_at timestamptz not null default now()
);

create index if not exists idx_coleta_status_eventos_agendamento on public.coleta_status_eventos(agendamento_id,created_at desc);
alter table public.coleta_status_eventos enable row level security;
drop policy if exists "acesso_coleta_status_eventos" on public.coleta_status_eventos;
create policy "acesso_coleta_status_eventos" on public.coleta_status_eventos for all to anon, authenticated using (true) with check (true);

select 'V17: painel operacional de coletas Rodonaves configurado.' as resultado;
