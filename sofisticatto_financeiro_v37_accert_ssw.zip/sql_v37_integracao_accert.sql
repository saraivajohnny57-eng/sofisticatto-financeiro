-- V37 — ACCERT / SSW — coleta automática
insert into public.frete_transportadoras(nome,observacao,ativa)
select 'ACCERT TRANSPORTES E LOGISTICA','Integração SSW: coleta liberada; demais serviços aguardando autorizações/tokens SSW.',true
where not exists(select 1 from public.frete_transportadoras where lower(nome) like '%accert%');
update public.frete_transportadoras set ativa=true where lower(nome) like '%accert%';

insert into public.integracao_convites(token,transportadora_nome,status,progresso,criado_por)
select 'accert-'||replace(gen_random_uuid()::text,'-',''),'ACCERT TRANSPORTES E LOGISTICA','em_implantacao',70,'sistema'
where not exists(select 1 from public.integracao_convites where lower(transportadora_nome) like '%accert%');

insert into public.transportadora_integracoes(convite_id,transportadora_nome,api_versao,status_tecnico,integracao_tipo,ambiente_atual,cotacao_ativa,prazo_ativo,coleta_ativa,rastreamento_ativo,comprovante_ativo,observacao_status,atualizado_em)
select c.id,c.transportadora_nome,'SSW WebService Coleta','configurando','webservice','producao',false,false,true,false,false,'Credenciais SSW recebidas. Coleta habilitada. Autorizações/tokens adicionais solicitados ao SSW para completar cotação/rastreamento/ocorrências.',now()
from public.integracao_convites c where lower(c.transportadora_nome) like '%accert%' order by c.created_at desc limit 1
on conflict(convite_id) do update set coleta_ativa=true,api_versao='SSW WebService Coleta',status_tecnico='configurando',integracao_tipo='webservice',ambiente_atual='producao',observacao_status=excluded.observacao_status,atualizado_em=now();

insert into public.transportadora_endpoints(convite_id,operacao,ambiente,metodo,formato,url,observacao)
select c.id,'coleta','producao','POST','SOAP/XML','https://ssw.inf.br/ws/sswColeta/index.php','WebService oficial SSW. Credenciais somente nas variáveis ACCERT_SSW_* da Vercel.'
from public.integracao_convites c where lower(c.transportadora_nome) like '%accert%' order by c.created_at desc limit 1
on conflict(convite_id,operacao,ambiente) do update set url=excluded.url,metodo=excluded.metodo,formato=excluded.formato,observacao=excluded.observacao,atualizado_em=now();
