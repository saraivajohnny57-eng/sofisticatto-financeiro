-- ============================================================
-- V16.3 — VALIDAÇÃO DA COMPARAÇÃO E FORMATOS DE PACKS
-- ============================================================

alter table public.rodonaves_cotacoes_api
  add column if not exists packs_modo text;

alter table public.integracao_homologacao_checklist
  add column if not exists cep_portal text,
  add column if not exists peso_portal numeric(14,3),
  add column if not exists volumes_portal integer,
  add column if not exists nf_portal numeric(14,2),
  add column if not exists altura_portal numeric(12,3),
  add column if not exists largura_portal numeric(12,3),
  add column if not exists comprimento_portal numeric(12,3),
  add column if not exists peso_unitario_portal numeric(14,3);

select 'V16.3: validação da comparação e formatos de Packs configurados.' as resultado;
