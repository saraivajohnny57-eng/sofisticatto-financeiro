alter table public.coleta_agendamentos
  add column if not exists chave_nfe text,
  add column if not exists numero_cte text,
  add column if not exists protocolo_rastreio text;

update public.coleta_agendamentos
set
  chave_nfe=coalesce(chave_nfe,nullif(trim(dados->>'chave_nfe'),''),nullif(trim(dados->>'chave_nf'),'')),
  numero_cte=coalesce(numero_cte,nullif(trim(dados->>'numero_cte'),'')),
  protocolo_rastreio=coalesce(protocolo_rastreio,nullif(trim(dados->>'protocolo_rastreio'),''))
where chave_nfe is null or numero_cte is null or protocolo_rastreio is null;

create or replace function public.fn_coleta_identificadores_para_rastreio()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  update public.logistica_rastreamentos r
  set numero_nfe=coalesce(nullif(trim(new.numero_nf),''),r.numero_nfe),
      chave_nfe=coalesce(nullif(regexp_replace(new.chave_nfe,'\D','','g'),''),r.chave_nfe),
      numero_cte=coalesce(nullif(trim(new.numero_cte),''),r.numero_cte),
      protocolo_rastreio=coalesce(nullif(trim(new.protocolo_rastreio),''),nullif(trim(new.protocolo_cotacao),''),r.protocolo_rastreio),
      atualizado_em=now()
  where r.coleta_agendamento_id=new.id;
  return new;
end;
$$;

drop trigger if exists trg_coleta_identificadores_para_rastreio on public.coleta_agendamentos;
create trigger trg_coleta_identificadores_para_rastreio
after update of numero_nf,chave_nfe,numero_cte,protocolo_rastreio,protocolo_cotacao
on public.coleta_agendamentos for each row
execute function public.fn_coleta_identificadores_para_rastreio();

select 'V33 instalada' as resultado;
