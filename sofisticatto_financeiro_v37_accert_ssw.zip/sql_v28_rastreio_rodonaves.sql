
-- V28 — rastreio automático Rodonaves

alter table public.logistica_rastreamentos
  add column if not exists coleta_agendamento_id uuid
    references public.coleta_agendamentos(id) on delete set null,
  add column if not exists origem text,
  add column if not exists status_api text,
  add column if not exists ultima_ocorrencia text,
  add column if not exists ultima_ocorrencia_em timestamptz,
  add column if not exists consulta_api jsonb,
  add column if not exists consultado_api_em timestamptz,
  add column if not exists sincronizacao_erro text;

create index if not exists idx_logistica_rastreamentos_coleta
  on public.logistica_rastreamentos(coleta_agendamento_id);

create index if not exists idx_logistica_rastreamentos_protocolo
  on public.logistica_rastreamentos(protocolo_rastreio);

-- Cria rastreios de saída para coletas Rodonaves que já possuem protocolo.
insert into public.logistica_rastreamentos (
  sentido,
  parceiro_nome,
  transportadora_id,
  protocolo_rastreio,
  data_postagem,
  volumes,
  status,
  observacao,
  coleta_agendamento_id,
  origem,
  atualizado_em,
  atualizado_por
)
select
  'saida',
  c.cliente_nome,
  c.transportadora_id,
  c.protocolo_cotacao,
  c.data_programada::date,
  c.volumes,
  case
    when c.status = 'coletado' then 'em_transito'
    else 'aguardando_coleta'
  end,
  'Criado automaticamente pela V28 a partir do Painel de Coletas.',
  c.id,
  'coleta_agendamento',
  now(),
  'migracao_v28'
from public.coleta_agendamentos c
join public.frete_transportadoras t on t.id = c.transportadora_id
where t.nome ilike '%Rodonaves%'
  and nullif(trim(c.protocolo_cotacao), '') is not null
  and not exists (
    select 1
    from public.logistica_rastreamentos r
    where r.coleta_agendamento_id = c.id
       or (
         r.transportadora_id = c.transportadora_id
         and r.protocolo_rastreio = c.protocolo_cotacao
       )
  );

select
  'V28 instalada' as resultado,
  count(*) filter (where origem in ('coleta_agendamento','coleta_importada')) as rastreios_vinculados
from public.logistica_rastreamentos;
