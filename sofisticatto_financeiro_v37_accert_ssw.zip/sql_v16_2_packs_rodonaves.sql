-- ============================================================
-- V16.2 — PACKS E CUBAGEM RODONAVES
-- ============================================================

alter table public.rodonaves_cotacoes_api
  add column if not exists packs_enviados boolean not null default false,
  add column if not exists packs_quantidade integer not null default 0,
  add column if not exists packs_payload jsonb;

select 'V16.2: Packs e cubagem da Rodonaves configurados.' as resultado;
