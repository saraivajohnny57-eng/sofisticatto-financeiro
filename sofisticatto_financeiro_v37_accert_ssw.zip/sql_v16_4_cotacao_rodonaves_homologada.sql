-- ============================================================
-- V16.4 — COTAÇÃO RODONAVES HOMOLOGADA
-- ============================================================

alter table public.integracao_homologacao_checklist
  add column if not exists homologacao_completa boolean not null default false,
  add column if not exists packs_modo_validado text,
  add column if not exists homologado_em timestamptz;

-- Registra como concluída a homologação já validada em tela:
-- valor e prazo iguais, comparação aprovada e cubagem/Packs marcada.
update public.integracao_homologacao_checklist
set
  homologacao_completa = true,
  packs_modo_validado = coalesce(packs_modo_validado,'agrupado'),
  homologado_em = coalesce(homologado_em,now()),
  percentual = 100,
  atualizado_em = now()
where autenticacao = true
  and cidades = true
  and cotacao = true
  and prazo = true
  and protocolo = true
  and comparado_portal = true
  and cubagem_validada = true;

select 'V16.4: cotação CIF da Rodonaves homologada em 100%.' as resultado;
