-- V27 — corrige registros externos em que o protocolo foi salvo como código da coleta.
-- Mantém o número como referência externa e remove do campo consultado pela API.

update public.coleta_agendamentos
set
  dados = coalesce(dados, '{}'::jsonb) || jsonb_build_object(
    'numero_referencia_externa', codigo_coleta,
    'codigo_coleta_validado', false,
    'correcao_v27_em', now()
  ),
  codigo_coleta = null,
  sincronizacao_erro = null,
  atualizado_em = now()
where origem = 'importacao_externa'
  and codigo_coleta is not null
  and (
    codigo_coleta = protocolo_cotacao
    or coalesce((dados->>'codigo_coleta_validado')::boolean, false) = false
  );

-- Resultado para conferência:
select id, cliente_nome, protocolo_cotacao, codigo_coleta,
       dados->>'numero_referencia_externa' as referencia_externa,
       dados->>'codigo_coleta_validado' as codigo_validado
from public.coleta_agendamentos
where origem = 'importacao_externa'
order by atualizado_em desc;
