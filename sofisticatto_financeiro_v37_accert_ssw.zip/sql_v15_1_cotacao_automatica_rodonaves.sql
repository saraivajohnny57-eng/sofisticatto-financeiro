-- ============================================================
-- V15.1 — COTAÇÃO AUTOMÁTICA RODONAVES
-- ============================================================

create table if not exists public.rodonaves_cidades_cache (
  cep text primary key,
  cidade_id integer not null,
  cidade text,
  uf text,
  resposta jsonb,
  atualizado_em timestamptz not null default now()
);

create table if not exists public.rodonaves_cotacoes_api (
  id uuid primary key default gen_random_uuid(),
  cotacao_id uuid references public.frete_cotacoes(id) on delete set null,
  convite_id uuid references public.integracao_convites(id) on delete set null,
  cliente_nome text,
  cpf_cnpj_destino text,
  cep_origem text,
  cidade_origem_id integer,
  cep_destino text,
  cidade_destino_id integer,
  valor_frete numeric(14,2),
  prazo_dias integer,
  numero_cotacao text,
  payload_enviado jsonb,
  resposta_recebida jsonb,
  sucesso boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists idx_rodonaves_cotacoes_api_cotacao
  on public.rodonaves_cotacoes_api(cotacao_id);

create index if not exists idx_rodonaves_cotacoes_api_data
  on public.rodonaves_cotacoes_api(created_at desc);

alter table public.rodonaves_cidades_cache enable row level security;
alter table public.rodonaves_cotacoes_api enable row level security;

-- O backend usa Service Role. O navegador não precisa gravar nem ler os payloads.
-- Portanto, não são criadas políticas públicas para essas tabelas.

select 'V15.1: cotação automática Rodonaves configurada.' as resultado;
