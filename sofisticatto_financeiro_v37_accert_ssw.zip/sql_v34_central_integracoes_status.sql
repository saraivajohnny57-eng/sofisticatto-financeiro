-- ============================================================
-- V34 — CENTRAL DE INTEGRAÇÕES / STATUS PROFISSIONAL
-- ============================================================

alter table public.transportadora_integracoes
  add column if not exists integracao_tipo text default 'api',
  add column if not exists ambiente_atual text default 'homologacao',
  add column if not exists comprovante_ativo boolean not null default false,
  add column if not exists ultima_sincronizacao_em timestamptz,
  add column if not exists observacao_status text;

-- Atualiza a restrição do status para suportar "aguardando credenciais".
alter table public.transportadora_integracoes
  drop constraint if exists transportadora_integracoes_status_tecnico_check;

alter table public.transportadora_integracoes
  add constraint transportadora_integracoes_status_tecnico_check
  check (status_tecnico in (
    'aguardando_credenciais',
    'configurando',
    'homologacao',
    'homologacao_aprovada',
    'producao',
    'suspensa'
  ));

-- Restrições leves dos novos campos.
alter table public.transportadora_integracoes
  drop constraint if exists transportadora_integracoes_integracao_tipo_check;

alter table public.transportadora_integracoes
  add constraint transportadora_integracoes_integracao_tipo_check
  check (integracao_tipo in ('api','webservice','edi','ssw','portal','manual'));

alter table public.transportadora_integracoes
  drop constraint if exists transportadora_integracoes_ambiente_atual_check;

alter table public.transportadora_integracoes
  add constraint transportadora_integracoes_ambiente_atual_check
  check (ambiente_atual in ('homologacao','producao'));

-- A Rodonaves já está operacional no projeto: corrige a ficha técnica.
update public.transportadora_integracoes
set
  status_tecnico='producao',
  integracao_tipo='api',
  ambiente_atual='producao',
  cotacao_ativa=true,
  prazo_ativo=true,
  coleta_ativa=true,
  rastreamento_ativo=true,
  observacao_status='Integração validada e operacional em produção',
  ultima_sincronizacao_em=coalesce(ultima_sincronizacao_em, now()),
  atualizado_em=now()
where lower(transportadora_nome) like '%rodonaves%';

select
  transportadora_nome,
  status_tecnico,
  integracao_tipo,
  ambiente_atual,
  cotacao_ativa,
  coleta_ativa,
  rastreamento_ativo,
  comprovante_ativo
from public.transportadora_integracoes
order by transportadora_nome;
