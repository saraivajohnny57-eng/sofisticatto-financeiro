alter table public.email_clientes
  alter column vendedora_id drop not null;

select 'Agora clientes podem ser importados sem vendedora.' as resultado;
