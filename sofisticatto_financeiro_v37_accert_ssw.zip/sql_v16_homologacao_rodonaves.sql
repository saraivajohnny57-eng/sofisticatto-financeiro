-- ============================================================
-- V16 — HOMOLOGAÇÃO AVANÇADA RODONAVES
-- ============================================================

alter table public.rodonaves_cotacoes_api
  add column if not exists peso_total numeric(14,3),
  add column if not exists volumes integer,
  add column if not exists altura_cm numeric(12,3),
  add column if not exists largura_cm numeric(12,3),
  add column if not exists comprimento_cm numeric(12,3),
  add column if not exists peso_unitario numeric(14,3),
  add column if not exists cubagem_total numeric(14,6),
  add column if not exists embalagem text,
  add column if not exists servico text;

create table if not exists public.transportadora_servicos (
  id uuid primary key default gen_random_uuid(),
  convite_id uuid not null references public.integracao_convites(id) on delete cascade,
  codigo text not null,
  nome text not null,
  descricao text,
  modalidade text,
  ativo boolean not null default true,
  cotacao_automatica boolean not null default false,
  created_at timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (convite_id, codigo)
);

create table if not exists public.integracao_homologacao_checklist (
  id uuid primary key default gen_random_uuid(),
  convite_id uuid not null unique references public.integracao_convites(id) on delete cascade,
  autenticacao boolean not null default false,
  cidades boolean not null default false,
  cotacao boolean not null default false,
  prazo boolean not null default false,
  protocolo boolean not null default false,
  comparado_portal boolean not null default false,
  cubagem_validada boolean not null default false,
  percentual integer not null default 0,
  observacao text,
  created_at timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

alter table public.transportadora_servicos enable row level security;
alter table public.integracao_homologacao_checklist enable row level security;

drop policy if exists "acesso_transportadora_servicos" on public.transportadora_servicos;
create policy "acesso_transportadora_servicos"
  on public.transportadora_servicos
  for all to anon, authenticated
  using (true) with check (true);

drop policy if exists "acesso_integracao_homologacao_checklist"
  on public.integracao_homologacao_checklist;
create policy "acesso_integracao_homologacao_checklist"
  on public.integracao_homologacao_checklist
  for all to anon, authenticated
  using (true) with check (true);

-- Serviços iniciais da Rodonaves. O CIF automático é o único liberado.
insert into public.transportadora_servicos
  (convite_id,codigo,nome,descricao,modalidade,ativo,cotacao_automatica)
select
  c.id,'convencional','Convencional',
  'Serviço padrão para teste e homologação CIF.',
  'rodoviario',true,true
from public.integracao_convites c
where c.transportadora_nome ilike '%rodonaves%'
on conflict (convite_id,codigo) do update set
  nome=excluded.nome,
  descricao=excluded.descricao,
  modalidade=excluded.modalidade,
  ativo=excluded.ativo,
  cotacao_automatica=excluded.cotacao_automatica,
  atualizado_em=now();

insert into public.transportadora_servicos
  (convite_id,codigo,nome,descricao,modalidade,ativo,cotacao_automatica)
select
  c.id,'fob_manual','FOB manual',
  'Cotação por WhatsApp ou telefone.',
  'manual',true,false
from public.integracao_convites c
where c.transportadora_nome ilike '%rodonaves%'
on conflict (convite_id,codigo) do update set
  nome=excluded.nome,
  descricao=excluded.descricao,
  modalidade=excluded.modalidade,
  ativo=excluded.ativo,
  cotacao_automatica=excluded.cotacao_automatica,
  atualizado_em=now();

select 'V16: homologação avançada da Rodonaves configurada.' as resultado;
