-- ============================================================
-- V16.6 — NEGOCIAÇÃO DE FRETE E PROTOCOLO PARA COLETA
-- ============================================================

alter table public.frete_cotacao_respostas
  add column if not exists negociada boolean not null default false,
  add column if not exists negociado_em timestamptz,
  add column if not exists negociado_por text,
  add column if not exists protocolo_usado_coleta text,
  add column if not exists valor_usado_coleta numeric(15,2);

create table if not exists public.frete_cotacao_negociacoes (
  id uuid primary key default gen_random_uuid(),
  cotacao_id uuid not null references public.frete_cotacoes(id) on delete cascade,
  transportadora_id uuid not null references public.frete_transportadoras(id) on delete restrict,
  resposta_id uuid references public.frete_cotacao_respostas(id) on delete set null,
  tipo_frete text not null default 'CIF',
  protocolo_anterior text,
  protocolo_novo text,
  valor_anterior numeric(15,2),
  valor_novo numeric(15,2),
  prazo_anterior text,
  prazo_novo text,
  motivo text,
  alterado_por text,
  created_at timestamptz not null default now()
);

create index if not exists idx_frete_negociacoes_cotacao
  on public.frete_cotacao_negociacoes(cotacao_id,created_at desc);

alter table public.frete_cotacao_negociacoes enable row level security;

drop policy if exists "acesso_frete_cotacao_negociacoes"
  on public.frete_cotacao_negociacoes;

create policy "acesso_frete_cotacao_negociacoes"
  on public.frete_cotacao_negociacoes
  for all to anon, authenticated
  using (true)
  with check (true);

select 'V16.6: negociação de frete e protocolo para coleta configurados.' as resultado;
