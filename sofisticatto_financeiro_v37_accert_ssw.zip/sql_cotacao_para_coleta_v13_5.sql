-- ============================================================
-- V13.5 — COTAÇÃO AUTORIZADA → AGENDAMENTO DE COLETA
-- ============================================================
alter table public.frete_transportadoras
  add column if not exists modelo_coleta_id uuid
  references public.coleta_modelos(id) on delete set null;

alter table public.frete_transportadoras
  add column if not exists criar_coleta_ao_autorizar boolean not null default false;

alter table public.coleta_agendamentos
  add column if not exists cotacao_id uuid
  references public.frete_cotacoes(id) on delete set null;

alter table public.coleta_agendamentos
  add column if not exists resposta_cotacao_id uuid
  references public.frete_cotacao_respostas(id) on delete set null;

alter table public.coleta_agendamentos
  add column if not exists origem text not null default 'manual';

create index if not exists idx_coleta_agendamentos_cotacao
  on public.coleta_agendamentos(cotacao_id);

select 'V13.5: integração entre cotação e coleta configurada.' as resultado;
