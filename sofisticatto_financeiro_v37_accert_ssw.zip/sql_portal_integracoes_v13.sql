-- ============================================================
-- V13 — PORTAL DE INTEGRAÇÕES DE TRANSPORTADORAS
-- ============================================================
create extension if not exists pgcrypto;

create table if not exists public.integracao_convites (
  id uuid primary key default gen_random_uuid(),
  token text not null unique,
  transportadora_nome text not null,
  cnpj text,
  contato_nome text,
  contato_email text,
  status text not null default 'convidado'
    check (status in ('convidado','rascunho','enviado','revisao','aprovado','inativo')),
  progresso integer not null default 0 check (progresso between 0 and 100),
  expira_em timestamptz,
  criado_por text,
  created_at timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create table if not exists public.integracao_formularios (
  id uuid primary key default gen_random_uuid(),
  convite_id uuid not null unique references public.integracao_convites(id) on delete cascade,
  dados jsonb not null default '{}'::jsonb,
  etapa_atual integer not null default 1,
  created_at timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create table if not exists public.integracao_arquivos (
  id uuid primary key default gen_random_uuid(),
  convite_id uuid not null references public.integracao_convites(id) on delete cascade,
  nome_arquivo text not null,
  caminho text not null,
  tamanho bigint,
  tipo_mime text,
  created_at timestamptz not null default now()
);

create table if not exists public.integracao_mensagens (
  id uuid primary key default gen_random_uuid(),
  convite_id uuid not null references public.integracao_convites(id) on delete cascade,
  remetente_tipo text not null check (remetente_tipo in ('sofisticatto','transportadora')),
  mensagem text not null,
  lida boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists idx_integracao_convites_status on public.integracao_convites(status);
create index if not exists idx_integracao_convites_token on public.integracao_convites(token);
create index if not exists idx_integracao_arquivos_convite on public.integracao_arquivos(convite_id);

alter table public.integracao_convites enable row level security;
alter table public.integracao_formularios enable row level security;
alter table public.integracao_arquivos enable row level security;
alter table public.integracao_mensagens enable row level security;

drop policy if exists "acesso_integracao_convites" on public.integracao_convites;
create policy "acesso_integracao_convites" on public.integracao_convites
  for all to anon, authenticated using (true) with check (true);

drop policy if exists "acesso_integracao_formularios" on public.integracao_formularios;
create policy "acesso_integracao_formularios" on public.integracao_formularios
  for all to anon, authenticated using (true) with check (true);

drop policy if exists "acesso_integracao_arquivos" on public.integracao_arquivos;
create policy "acesso_integracao_arquivos" on public.integracao_arquivos
  for all to anon, authenticated using (true) with check (true);

drop policy if exists "acesso_integracao_mensagens" on public.integracao_mensagens;
create policy "acesso_integracao_mensagens" on public.integracao_mensagens
  for all to anon, authenticated using (true) with check (true);

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values (
  'integracoes-documentos',
  'integracoes-documentos',
  false,
  20971520,
  array[
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/json',
    'application/xml',
    'text/xml',
    'text/plain',
    'text/csv',
    'application/zip',
    'application/x-yaml',
    'text/yaml'
  ]
)
on conflict (id) do nothing;

drop policy if exists "upload_integracoes_documentos" on storage.objects;
create policy "upload_integracoes_documentos" on storage.objects
  for insert to anon, authenticated
  with check (bucket_id='integracoes-documentos');

drop policy if exists "leitura_integracoes_documentos" on storage.objects;
create policy "leitura_integracoes_documentos" on storage.objects
  for select to anon, authenticated
  using (bucket_id='integracoes-documentos');

select 'V13: Portal de Integrações configurado com sucesso.' as resultado;
