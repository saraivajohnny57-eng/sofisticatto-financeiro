-- ============================================================
-- V32 — RASTREIO SEM DUPLICADOS
-- ============================================================
-- Objetivo:
-- 1) limpar duplicidades já existentes;
-- 2) ao editar NF/chave/CT-e/protocolo, consolidar em um único registro;
-- 3) preservar vínculo com coleta e dados retornados pela API.

create or replace function public.fn_status_rastreio_rank(p_status text)
returns integer
language sql
immutable
as $$
  select case lower(coalesce(p_status,''))
    when 'entregue' then 90
    when 'recebido' then 90
    when 'saiu_entrega' then 80
    when 'na_filial' then 70
    when 'em_transito' then 60
    when 'atrasado' then 55
    when 'ocorrencia' then 50
    when 'aguardando_coleta' then 20
    when 'cancelado' then 10
    else 0
  end;
$$;

create or replace function public.fn_deduplicar_rastreamento(p_id uuid)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v public.logistica_rastreamentos%rowtype;
  d public.logistica_rastreamentos%rowtype;
  v_coleta uuid;
  v_status text;
  v_status_rank integer;
begin
  select * into v
  from public.logistica_rastreamentos
  where id=p_id;

  if not found then
    return null;
  end if;

  v_coleta:=v.coleta_agendamento_id;
  v_status:=v.status;
  v_status_rank:=public.fn_status_rastreio_rank(v.status);

  for d in
    select *
    from public.logistica_rastreamentos x
    where x.id<>v.id
      and x.sentido=v.sentido
      and (
        x.transportadora_id=v.transportadora_id
        or (x.transportadora_id is null and v.transportadora_id is null)
      )
      and (
        (
          nullif(trim(v.chave_nfe),'') is not null
          and nullif(trim(x.chave_nfe),'')=nullif(trim(v.chave_nfe),'')
        )
        or (
          nullif(trim(v.numero_cte),'') is not null
          and nullif(trim(x.numero_cte),'')=nullif(trim(v.numero_cte),'')
        )
        or (
          nullif(trim(v.numero_nfe),'') is not null
          and nullif(trim(x.numero_nfe),'')=nullif(trim(v.numero_nfe),'')
        )
        or (
          nullif(trim(v.protocolo_rastreio),'') is not null
          and nullif(trim(x.protocolo_rastreio),'')=nullif(trim(v.protocolo_rastreio),'')
        )
      )
    order by
      (x.coleta_agendamento_id is not null) desc,
      (x.consultado_api_em is not null) desc,
      x.atualizado_em desc nulls last,
      x.created_at desc
  loop
    if v_coleta is null and d.coleta_agendamento_id is not null then
      v_coleta:=d.coleta_agendamento_id;
    end if;

    if public.fn_status_rastreio_rank(d.status)>v_status_rank then
      v_status:=d.status;
      v_status_rank:=public.fn_status_rastreio_rank(d.status);
    end if;

    update public.logistica_rastreamentos
    set
      numero_nfe=coalesce(nullif(trim(numero_nfe),''),nullif(trim(d.numero_nfe),'')),
      chave_nfe=coalesce(nullif(trim(chave_nfe),''),nullif(trim(d.chave_nfe),'')),
      numero_cte=coalesce(nullif(trim(numero_cte),''),nullif(trim(d.numero_cte),'')),
      protocolo_rastreio=coalesce(nullif(trim(protocolo_rastreio),''),nullif(trim(d.protocolo_rastreio),'')),
      data_postagem=coalesce(data_postagem,d.data_postagem),
      previsao_entrega=coalesce(previsao_entrega,d.previsao_entrega),
      volumes=coalesce(volumes,d.volumes),
      status_api=coalesce(status_api,d.status_api),
      ultima_ocorrencia=coalesce(ultima_ocorrencia,d.ultima_ocorrencia),
      ultima_ocorrencia_em=coalesce(ultima_ocorrencia_em,d.ultima_ocorrencia_em),
      consulta_api=coalesce(consulta_api,d.consulta_api),
      consultado_api_em=greatest(consultado_api_em,d.consultado_api_em),
      metodo_consulta=coalesce(metodo_consulta,d.metodo_consulta),
      origem=coalesce(origem,d.origem),
      observacao=coalesce(observacao,d.observacao),
      atualizado_em=now()
    where id=v.id;

    -- Remove o gêmeo somente depois de copiar seus dados importantes.
    delete from public.logistica_rastreamentos where id=d.id;
  end loop;

  update public.logistica_rastreamentos
  set
    coleta_agendamento_id=v_coleta,
    status=v_status,
    atualizado_em=now()
  where id=v.id;

  return v.id;
end;
$$;

-- Trigger: qualquer INSERT/UPDATE de identificadores passa por deduplicação.
create or replace function public.trg_fn_deduplicar_rastreamento()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if pg_trigger_depth()<2 then
    perform public.fn_deduplicar_rastreamento(new.id);
  end if;
  return new;
end;
$$;

drop trigger if exists trg_deduplicar_rastreamento
  on public.logistica_rastreamentos;

create trigger trg_deduplicar_rastreamento
after insert or update of
  numero_nfe,chave_nfe,numero_cte,protocolo_rastreio,transportadora_id
on public.logistica_rastreamentos
for each row
execute function public.trg_fn_deduplicar_rastreamento();

-- Índices para localizar rapidamente registros já existentes.
create index if not exists idx_rastreio_transportadora_nfe
  on public.logistica_rastreamentos(transportadora_id,sentido,numero_nfe)
  where nullif(trim(numero_nfe),'') is not null;

create index if not exists idx_rastreio_transportadora_cte
  on public.logistica_rastreamentos(transportadora_id,sentido,numero_cte)
  where nullif(trim(numero_cte),'') is not null;

create index if not exists idx_rastreio_transportadora_chave
  on public.logistica_rastreamentos(transportadora_id,sentido,chave_nfe)
  where nullif(trim(chave_nfe),'') is not null;

create index if not exists idx_rastreio_transportadora_protocolo
  on public.logistica_rastreamentos(transportadora_id,sentido,protocolo_rastreio)
  where nullif(trim(protocolo_rastreio),'') is not null;

-- Limpeza dos duplicados que já existem.
-- Mantemos primeiro os registros mais completos/vinculados à coleta/API.
do $$
declare
  r record;
begin
  for r in
    select id
    from public.logistica_rastreamentos
    order by
      (coleta_agendamento_id is not null) desc,
      (consultado_api_em is not null) desc,
      atualizado_em desc nulls last,
      created_at desc
  loop
    if exists(select 1 from public.logistica_rastreamentos where id=r.id) then
      perform public.fn_deduplicar_rastreamento(r.id);
    end if;
  end loop;
end;
$$;

select
  'V32 instalada — rastreios consolidados' as resultado,
  count(*) as total_rastreios
from public.logistica_rastreamentos;
