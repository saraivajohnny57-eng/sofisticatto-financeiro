-- V36 — INTEGRAÇÃO ALFA TRANSPORTES
-- Execute depois de publicar os arquivos da V36.

insert into public.frete_transportadoras(nome, observacao, ativa)
select 'ALFA TRANSPORTES', 'Cotação e rastreamento integrados por API oficial Alfa.', true
where not exists (
  select 1 from public.frete_transportadoras where lower(nome) like '%alfa%'
);

-- Se a Alfa já existir, apenas garante que esteja ativa.
update public.frete_transportadoras
set ativa=true,
    observacao=coalesce(observacao,'') || case when coalesce(observacao,'') ilike '%API oficial Alfa%' then '' else ' | API oficial Alfa: cotação e rastreamento.' end
where lower(nome) like '%alfa%';

-- Cria um convite técnico para a Central de Integrações caso ainda não exista.
insert into public.integracao_convites(token,transportadora_nome,status,progresso,criado_por)
select 'alfa-' || replace(gen_random_uuid()::text,'-',''), 'ALFA TRANSPORTES', 'aprovado', 100, 'sistema'
where not exists (
  select 1 from public.integracao_convites where lower(transportadora_nome) like '%alfa%'
);

-- Marca a integração como API ativa em produção.
insert into public.transportadora_integracoes(
  convite_id,transportadora_nome,api_versao,status_tecnico,integracao_tipo,ambiente_atual,
  cotacao_ativa,prazo_ativo,coleta_ativa,rastreamento_ativo,comprovante_ativo,
  observacao_status,ultima_sincronizacao_em,atualizado_em
)
select c.id,c.transportadora_nome,'cotação v1.2 / rastreamento v1.3','producao','api','producao',
       true,true,false,true,true,
       'API Alfa liberada: cotação e rastreamento. Coleta aguardando retorno do NTI.',now(),now()
from public.integracao_convites c
where lower(c.transportadora_nome) like '%alfa%'
order by c.created_at desc limit 1
on conflict (convite_id) do update set
  api_versao=excluded.api_versao,status_tecnico='producao',integracao_tipo='api',ambiente_atual='producao',
  cotacao_ativa=true,prazo_ativo=true,rastreamento_ativo=true,comprovante_ativo=true,
  observacao_status=excluded.observacao_status,atualizado_em=now();

-- Documenta os endpoints públicos oficiais, sem gravar a chave secreta.
insert into public.transportadora_endpoints(convite_id,operacao,ambiente,metodo,formato,url,observacao)
select c.id,'cotacao','producao','POST','json','https://api.alfatransportes.com.br/cotacao/v1.2/',
       'API oficial Alfa Transportes - chave armazenada somente na Vercel (ALFA_API_KEY)'
from public.integracao_convites c where lower(c.transportadora_nome) like '%alfa%'
order by c.created_at desc limit 1
on conflict (convite_id,operacao,ambiente) do update set url=excluded.url,metodo='POST',formato='json',observacao=excluded.observacao,atualizado_em=now();

insert into public.transportadora_endpoints(convite_id,operacao,ambiente,metodo,formato,url,observacao)
select c.id,'rastreamento','producao','POST','json','https://api.alfatransportes.com.br/rastreamento/v1.3/',
       'Rastreamento Alfa por número da NF; retorna CT-e, previsão, ocorrências, entrega e comprovante.'
from public.integracao_convites c where lower(c.transportadora_nome) like '%alfa%'
order by c.created_at desc limit 1
on conflict (convite_id,operacao,ambiente) do update set url=excluded.url,metodo='POST',formato='json',observacao=excluded.observacao,atualizado_em=now();

select transportadora_nome,status_tecnico,cotacao_ativa,prazo_ativo,coleta_ativa,rastreamento_ativo,comprovante_ativo
from public.transportadora_integracoes where lower(transportadora_nome) like '%alfa%';
