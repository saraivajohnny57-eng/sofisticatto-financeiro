-- V29 — Consulta inteligente de rastreio Rodonaves
-- Ordem automática: Protocolo/Minuta → Nota Fiscal → CT-e → Chave da NF-e.

alter table public.logistica_rastreamentos
  add column if not exists metodo_consulta text;

-- Copia o número da nota fiscal registrado no agendamento para o rastreio vinculado.
update public.logistica_rastreamentos r
set
  numero_nfe = coalesce(
    nullif(trim(r.numero_nfe), ''),
    nullif(trim(c.dados->>'numero_nf'), ''),
    nullif(trim(c.dados->>'numero_nfe'), '')
  ),
  chave_nfe = coalesce(
    nullif(trim(r.chave_nfe), ''),
    nullif(trim(c.dados->>'chave_nfe'), ''),
    nullif(trim(c.dados->>'chave_nf'), '')
  ),
  atualizado_em = now()
from public.coleta_agendamentos c
where r.coleta_agendamento_id = c.id
  and (
    nullif(trim(r.numero_nfe), '') is null
    or nullif(trim(r.chave_nfe), '') is null
  );

-- Vincula por protocolo quando o vínculo direto ainda não existe.
update public.logistica_rastreamentos r
set
  coleta_agendamento_id = c.id,
  numero_nfe = coalesce(
    nullif(trim(r.numero_nfe), ''),
    nullif(trim(c.dados->>'numero_nf'), ''),
    nullif(trim(c.dados->>'numero_nfe'), '')
  ),
  chave_nfe = coalesce(
    nullif(trim(r.chave_nfe), ''),
    nullif(trim(c.dados->>'chave_nfe'), ''),
    nullif(trim(c.dados->>'chave_nf'), '')
  ),
  atualizado_em = now()
from public.coleta_agendamentos c
where r.coleta_agendamento_id is null
  and nullif(trim(r.protocolo_rastreio), '') is not null
  and r.protocolo_rastreio = c.protocolo_cotacao;

select
  r.parceiro_nome,
  r.protocolo_rastreio,
  r.numero_nfe,
  r.numero_cte,
  r.chave_nfe,
  r.metodo_consulta,
  r.status
from public.logistica_rastreamentos r
order by r.atualizado_em desc;
