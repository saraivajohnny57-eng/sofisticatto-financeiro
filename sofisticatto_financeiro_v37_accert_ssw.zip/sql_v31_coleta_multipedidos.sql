-- ============================================================
-- V31 — COLETA COM MÚLTIPLOS PEDIDOS + FILTRO DE RASTREIO
-- ============================================================
-- Permite agrupar vários pedidos/NFs em uma mesma coleta física.
-- Os totais de volumes e peso da coleta são recalculados automaticamente.
-- Se a coleta já foi solicitada, o sistema sinaliza que o ajuste precisa
-- ser confirmado com a transportadora.

alter table public.coleta_agendamentos
  add column if not exists ajuste_carga_pendente boolean not null default false,
  add column if not exists ajuste_carga_confirmado_em timestamptz;

create table if not exists public.coleta_pedidos_vinculados (
  id uuid primary key default gen_random_uuid(),
  agendamento_id uuid not null
    references public.coleta_agendamentos(id) on delete cascade,
  cliente_nome text not null,
  cliente_id uuid,
  numero_nf text,
  chave_nfe text,
  numero_cte text,
  volumes integer not null default 0 check (volumes >= 0),
  peso numeric(14,3) not null default 0 check (peso >= 0),
  valor_nf numeric(14,2),
  observacao text,
  principal boolean not null default false,
  criado_por text,
  created_at timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create index if not exists idx_coleta_pedidos_agendamento
  on public.coleta_pedidos_vinculados(agendamento_id,created_at);

create unique index if not exists uq_coleta_pedido_principal
  on public.coleta_pedidos_vinculados(agendamento_id)
  where principal=true;

alter table public.coleta_pedidos_vinculados enable row level security;

drop policy if exists "acesso_coleta_pedidos_vinculados"
  on public.coleta_pedidos_vinculados;

create policy "acesso_coleta_pedidos_vinculados"
  on public.coleta_pedidos_vinculados
  for all to anon, authenticated
  using (true)
  with check (true);

-- Cria automaticamente o pedido principal para coletas que já existem.
insert into public.coleta_pedidos_vinculados(
  agendamento_id,cliente_nome,cliente_id,numero_nf,chave_nfe,numero_cte,
  volumes,peso,valor_nf,observacao,principal,criado_por
)
select
  c.id,
  coalesce(c.cliente_nome,'Cliente'),
  c.cliente_id,
  coalesce(
    nullif(trim(c.numero_nf),''),
    nullif(trim(c.dados->>'numero_nf'),''),
    nullif(trim(c.dados->>'numero_nfe'),'')
  ),
  coalesce(
    nullif(trim(c.dados->>'chave_nfe'),''),
    nullif(trim(c.dados->>'chave_nf'),'')
  ),
  nullif(trim(c.dados->>'numero_cte'),''),
  coalesce(c.volumes,0),
  coalesce(c.peso,0),
  case
    when coalesce(c.dados->>'valor_nf','') ~ '^[0-9]+([.,][0-9]+)?$'
      then replace(c.dados->>'valor_nf',',','.')::numeric
    else null
  end,
  'Pedido original da coleta.',
  true,
  'migracao_v31'
from public.coleta_agendamentos c
where not exists (
  select 1 from public.coleta_pedidos_vinculados p
  where p.agendamento_id=c.id and p.principal=true
);

create or replace function public.fn_recalcular_totais_coleta_multipedidos()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_agendamento uuid;
  v_volumes integer;
  v_peso numeric(14,3);
  v_qtd integer;
  v_status text;
begin
  v_agendamento := coalesce(new.agendamento_id,old.agendamento_id);

  select
    coalesce(sum(volumes),0)::integer,
    coalesce(sum(peso),0)::numeric(14,3),
    count(*)::integer
  into v_volumes,v_peso,v_qtd
  from public.coleta_pedidos_vinculados
  where agendamento_id=v_agendamento;

  select lower(coalesce(status_api,status,''))
  into v_status
  from public.coleta_agendamentos
  where id=v_agendamento;

  update public.coleta_agendamentos
  set
    volumes=v_volumes,
    peso=v_peso,
    dados=jsonb_set(
      jsonb_set(
        coalesce(dados,'{}'::jsonb),
        '{pedidos_vinculados_total}',
        to_jsonb(v_qtd),
        true
      ),
      '{carga_total_atualizada_em}',
      to_jsonb(now()::text),
      true
    ),
    ajuste_carga_pendente=case
      when v_status in ('solicitado','em_aberto','confirmado','confirmada','em_coleta')
        then true
      else ajuste_carga_pendente
    end,
    atualizado_em=now()
  where id=v_agendamento;

  return coalesce(new,old);
end;
$$;

drop trigger if exists trg_recalcular_totais_coleta_multipedidos
  on public.coleta_pedidos_vinculados;

create trigger trg_recalcular_totais_coleta_multipedidos
after insert or update or delete
on public.coleta_pedidos_vinculados
for each row
execute function public.fn_recalcular_totais_coleta_multipedidos();

-- Mantém o rastreio vinculado com o total agregado da coleta.
create or replace function public.fn_atualizar_rastreio_totais_coleta()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  update public.logistica_rastreamentos
  set
    volumes=new.volumes,
    atualizado_em=now()
  where coleta_agendamento_id=new.id;
  return new;
end;
$$;

drop trigger if exists trg_atualizar_rastreio_totais_coleta
  on public.coleta_agendamentos;

create trigger trg_atualizar_rastreio_totais_coleta
after update of volumes,peso
on public.coleta_agendamentos
for each row
execute function public.fn_atualizar_rastreio_totais_coleta();

select
  'V31 instalada' as resultado,
  count(*) as pedidos_vinculados
from public.coleta_pedidos_vinculados;
