-- V24 não altera o banco.
-- Verificação opcional da estrutura criada na V21:

select
  to_regclass('public.integracao_sincronizacoes') as tabela_sincronizacoes,
  exists (
    select 1
    from information_schema.columns
    where table_schema='public'
      and table_name='coleta_agendamentos'
      and column_name='sincronizado_em'
  ) as sincronizado_em_ok,
  exists (
    select 1
    from information_schema.columns
    where table_schema='public'
      and table_name='coleta_agendamentos'
      and column_name='sincronizacao_erro'
  ) as sincronizacao_erro_ok;
