-- ============================================================
-- V12 — E-MAIL E VENDEDORA OPCIONAIS
-- ============================================================
alter table public.email_clientes alter column emails drop not null;
alter table public.email_clientes alter column vendedora_id drop not null;
alter table public.email_clientes alter column emails set default '{}'::text[];
update public.email_clientes set emails='{}'::text[] where emails is null;
alter table public.email_vendedoras alter column email drop not null;
alter table public.email_vendedoras alter column whatsapp drop not null;
alter table public.email_clientes alter column cpf_cnpj drop not null;
alter table public.email_clientes alter column telefone drop not null;
alter table public.email_clientes alter column celular drop not null;
alter table public.email_clientes alter column contato drop not null;
alter table public.email_clientes alter column endereco drop not null;
alter table public.email_clientes alter column numero drop not null;
alter table public.email_clientes alter column complemento drop not null;
alter table public.email_clientes alter column bairro drop not null;
alter table public.email_clientes alter column cep drop not null;
alter table public.email_clientes alter column cidade drop not null;
alter table public.email_clientes alter column uf drop not null;
alter table public.email_clientes alter column observacao drop not null;
create index if not exists idx_email_clientes_nome_normalizado on public.email_clientes (lower(nome));
create index if not exists idx_email_clientes_cpf_cnpj_v12 on public.email_clientes (cpf_cnpj);
select 'V12 configurada: e-mails e vendedora agora são opcionais.' as resultado;
