-- ============================================================
-- V16.9 — LOCAIS DE COLETA E ENDEREÇO ALTERNATIVO
-- ============================================================

create table if not exists public.coleta_locais (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  cnpj text,
  razao_social text,
  telefone text,
  cep text not null,
  logradouro text not null,
  numero text,
  complemento text,
  bairro text,
  cidade text not null,
  uf char(2) not null,
  referencia text,
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

alter table public.coleta_locais enable row level security;

drop policy if exists "acesso_coleta_locais" on public.coleta_locais;
create policy "acesso_coleta_locais"
  on public.coleta_locais
  for all to anon, authenticated
  using (true)
  with check (true);

alter table public.coleta_agendamentos
  add column if not exists modo_endereco text not null default 'protocolo',
  add column if not exists local_coleta_id uuid references public.coleta_locais(id) on delete set null,
  add column if not exists endereco_coleta_alternativo jsonb;

insert into public.coleta_locais
  (nome,cnpj,razao_social,telefone,cep,logradouro,numero,complemento,bairro,cidade,uf,referencia)
select
  'Produção — Rua 3',
  '05451985000195',
  'SOFISTICATTO COSMÉTICOS',
  '6232930035',
  '74550470',
  'Rua 03',
  '217',
  'Qd.35, Lt.14E',
  'Vila Abajá',
  'Goiânia',
  'GO',
  'Próximo ao Tático de Campinas'
where not exists (
  select 1 from public.coleta_locais where nome='Produção — Rua 3'
);

select 'V16.9: locais de coleta e endereço alternativo configurados.' as resultado;
