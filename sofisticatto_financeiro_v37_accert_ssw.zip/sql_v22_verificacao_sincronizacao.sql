-- V22 — não cria novas tabelas.
-- Execute somente para verificar se a estrutura da V21 existe.

select
  to_regclass('public.integracao_sincronizacoes') as tabela_sincronizacoes,
  exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'coleta_agendamentos'
      and column_name = 'sincronizado_em'
  ) as coluna_sincronizado_em,
  exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'coleta_agendamentos'
      and column_name = 'sincronizacao_erro'
  ) as coluna_sincronizacao_erro;
