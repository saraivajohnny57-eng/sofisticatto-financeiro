-- ============================================================
-- V14 — CREDENCIAIS SEGURAS E HOMOLOGAÇÃO
-- ============================================================

create table if not exists public.integracao_configuracoes (
  id uuid primary key default gen_random_uuid(),
  convite_id uuid not null unique
    references public.integracao_convites(id) on delete cascade,
  ambiente text not null default 'homologacao'
    check (ambiente in ('homologacao','producao')),
  status_tecnico text not null default 'aguardando_credenciais'
    check (status_tecnico in (
      'aguardando_credenciais','configurando','homologacao',
      'homologacao_aprovada','producao','suspensa'
    )),
  url_homologacao text,
  url_producao text,
  metodo text not null default 'POST'
    check (metodo in ('GET','POST','PUT')),
  formato text not null default 'json'
    check (formato in ('json','xml')),
  auth_tipo text not null default 'none'
    check (auth_tipo in ('none','bearer','api_key','basic','login_token')),
  api_key_header text default 'x-api-key',
  token_url text,
  usuario_campo text default 'username',
  senha_campo text default 'password',
  token_resposta_campo text default 'access_token',
  atualizado_por text,
  created_at timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create table if not exists public.integracao_credenciais (
  id uuid primary key default gen_random_uuid(),
  convite_id uuid not null
    references public.integracao_convites(id) on delete cascade,
  ambiente text not null
    check (ambiente in ('homologacao','producao')),
  payload_criptografado text not null,
  iv text not null,
  auth_tag text not null,
  created_at timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (convite_id, ambiente)
);

create table if not exists public.integracao_testes (
  id uuid primary key default gen_random_uuid(),
  convite_id uuid not null
    references public.integracao_convites(id) on delete cascade,
  ambiente text not null default 'homologacao',
  operacao text not null,
  url text,
  metodo text,
  http_status integer,
  tempo_ms integer,
  sucesso boolean not null default false,
  resposta_resumida jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_integracao_configuracoes_status
  on public.integracao_configuracoes(status_tecnico);

create index if not exists idx_integracao_testes_convite
  on public.integracao_testes(convite_id, created_at desc);

alter table public.integracao_configuracoes enable row level security;
alter table public.integracao_credenciais enable row level security;
alter table public.integracao_testes enable row level security;

-- Configurações sem segredos podem ser administradas pelo painel atual.
drop policy if exists "acesso_integracao_configuracoes"
  on public.integracao_configuracoes;

create policy "acesso_integracao_configuracoes"
  on public.integracao_configuracoes
  for all to anon, authenticated
  using (true)
  with check (true);

-- IMPORTANTE:
-- Não criar políticas anon/authenticated para integracao_credenciais.
-- Somente a Service Role usada pelas funções da Vercel terá acesso.

-- Os testes podem ser lidos pelo painel, mas são gravados pelo backend.
drop policy if exists "leitura_integracao_testes"
  on public.integracao_testes;

create policy "leitura_integracao_testes"
  on public.integracao_testes
  for select to anon, authenticated
  using (true);

select 'V14: credenciais seguras e homologação configuradas.' as resultado;
