-- ============================================================
-- V13.4 — AGENDAMENTO DE COLETAS
-- ============================================================
create table if not exists public.coleta_modelos (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  transportadora_id uuid references public.frete_transportadoras(id) on delete set null,
  texto text not null,
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create table if not exists public.coleta_agendamentos (
  id uuid primary key default gen_random_uuid(),
  cliente_id uuid references public.email_clientes(id) on delete set null,
  cliente_nome text not null,
  transportadora_id uuid references public.frete_transportadoras(id) on delete set null,
  modelo_id uuid references public.coleta_modelos(id) on delete set null,
  tipo_frete text not null default 'CIF' check (tipo_frete in ('CIF','FOB')),
  dados jsonb not null default '{}'::jsonb,
  mensagem text not null,
  volumes integer,
  peso numeric(12,3),
  numero_nf text,
  status text not null default 'rascunho'
    check (status in ('rascunho','solicitado','confirmado','coletado','cancelado')),
  observacao text,
  criado_por text,
  created_at timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create index if not exists idx_coleta_agendamentos_status on public.coleta_agendamentos(status);
create index if not exists idx_coleta_agendamentos_cliente on public.coleta_agendamentos(cliente_id);
create index if not exists idx_coleta_agendamentos_transportadora on public.coleta_agendamentos(transportadora_id);

alter table public.coleta_modelos enable row level security;
alter table public.coleta_agendamentos enable row level security;

drop policy if exists "acesso_coleta_modelos" on public.coleta_modelos;
create policy "acesso_coleta_modelos" on public.coleta_modelos
  for all to anon, authenticated using (true) with check (true);

drop policy if exists "acesso_coleta_agendamentos" on public.coleta_agendamentos;
create policy "acesso_coleta_agendamentos" on public.coleta_agendamentos
  for all to anon, authenticated using (true) with check (true);

select 'V13.4: módulo de agendamento de coleta configurado.' as resultado;
