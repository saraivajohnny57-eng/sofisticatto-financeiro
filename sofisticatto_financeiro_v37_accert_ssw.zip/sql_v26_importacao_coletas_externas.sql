-- V26 — campos opcionais para relatórios de coletas externas.
-- O sistema funciona sem estas colunas porque também salva os dados no campo JSON "dados".
-- Execute para facilitar filtros e relatórios futuros.

alter table public.coleta_agendamentos
  add column if not exists origem_externa text,
  add column if not exists importado_externo_em timestamptz,
  add column if not exists vinculado_manualmente_em timestamptz;

create index if not exists coleta_agendamentos_origem_externa_idx
  on public.coleta_agendamentos (origem_externa);

comment on column public.coleta_agendamentos.origem_externa is
  'Origem da coleta externa: whatsapp, portal_transportadora, comercial, telefone ou manual.';
