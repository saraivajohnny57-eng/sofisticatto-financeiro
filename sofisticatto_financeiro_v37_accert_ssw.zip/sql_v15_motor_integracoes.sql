-- ============================================================
-- V15 — MOTOR DE INTEGRAÇÕES V1
-- ============================================================
create table if not exists public.transportadora_integracoes (
  id uuid primary key default gen_random_uuid(),
  convite_id uuid not null unique references public.integracao_convites(id) on delete cascade,
  transportadora_nome text not null,
  api_versao text default 'v1',
  status_tecnico text not null default 'configurando'
    check (status_tecnico in ('configurando','homologacao','homologacao_aprovada','producao','suspensa')),
  cotacao_ativa boolean not null default false,
  prazo_ativo boolean not null default false,
  coleta_ativa boolean not null default false,
  rastreamento_ativo boolean not null default false,
  created_at timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create table if not exists public.transportadora_endpoints (
  id uuid primary key default gen_random_uuid(),
  convite_id uuid not null references public.integracao_convites(id) on delete cascade,
  operacao text not null check (operacao in ('token','cotacao','cidade','prazo','coleta','rastreamento','comprovante')),
  ambiente text not null default 'homologacao' check (ambiente in ('homologacao','producao')),
  metodo text not null default 'POST' check (metodo in ('GET','POST','PUT')),
  formato text not null default 'json' check (formato in ('json','form','xml')),
  url text not null,
  observacao text,
  created_at timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (convite_id, operacao, ambiente)
);

create table if not exists public.integracao_logs (
  id uuid primary key default gen_random_uuid(),
  convite_id uuid references public.integracao_convites(id) on delete set null,
  transportadora_nome text,
  operacao text not null,
  ambiente text not null default 'homologacao',
  http_status integer,
  tempo_ms integer,
  sucesso boolean not null default false,
  mensagem text,
  resposta_resumida jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_transportadora_endpoints_convite
  on public.transportadora_endpoints(convite_id, operacao);
create index if not exists idx_integracao_logs_data
  on public.integracao_logs(created_at desc);

alter table public.transportadora_integracoes enable row level security;
alter table public.transportadora_endpoints enable row level security;
alter table public.integracao_logs enable row level security;

drop policy if exists "acesso_transportadora_integracoes" on public.transportadora_integracoes;
create policy "acesso_transportadora_integracoes" on public.transportadora_integracoes
  for all to anon, authenticated using (true) with check (true);

drop policy if exists "acesso_transportadora_endpoints" on public.transportadora_endpoints;
create policy "acesso_transportadora_endpoints" on public.transportadora_endpoints
  for all to anon, authenticated using (true) with check (true);

drop policy if exists "leitura_integracao_logs" on public.integracao_logs;
create policy "leitura_integracao_logs" on public.integracao_logs
  for select to anon, authenticated using (true);

select 'V15: Motor de Integrações V1 configurado.' as resultado;
