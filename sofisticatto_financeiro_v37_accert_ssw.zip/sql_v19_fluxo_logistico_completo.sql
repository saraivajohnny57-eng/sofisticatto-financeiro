-- ============================================================
-- V19 — FLUXO LOGÍSTICO COMPLETO
-- Coletas manuais, saídas, entradas e transportadoras
-- ============================================================

alter table public.coleta_agendamentos
  add column if not exists coletado_em timestamptz;

alter table public.coleta_agendamentos
  drop constraint if exists coleta_agendamentos_status_check;

alter table public.coleta_agendamentos
  add constraint coleta_agendamentos_status_check
  check (status in (
    'rascunho','solicitado','em_aberto','confirmado','em_coleta',
    'coletado','nao_coletada','reagendada',
    'cancelamento_solicitado','cancelado','erro'
  ));

alter table public.frete_transportadoras
  add column if not exists telefone text,
  add column if not exists tipo_acompanhamento text not null default 'manual'
    check (tipo_acompanhamento in ('manual','api','portal'));

create table if not exists public.logistica_rastreamentos (
  id uuid primary key default gen_random_uuid(),
  sentido text not null check (sentido in ('saida','entrada')),
  parceiro_nome text not null,
  transportadora_id uuid references public.frete_transportadoras(id) on delete set null,
  numero_nfe text,
  chave_nfe text,
  numero_cte text,
  protocolo_rastreio text,
  data_postagem date,
  previsao_entrega date,
  volumes integer,
  status text not null default 'aguardando_coleta'
    check (status in (
      'aguardando_coleta','em_transito','na_filial','saiu_entrega',
      'entregue','recebido','atrasado','ocorrencia','cancelado'
    )),
  observacao text,
  finalizado_em timestamptz,
  atualizado_em timestamptz not null default now(),
  atualizado_por text,
  created_at timestamptz not null default now()
);

create index if not exists idx_logistica_rastreamentos_sentido_status
  on public.logistica_rastreamentos(sentido,status,created_at desc);

create index if not exists idx_logistica_rastreamentos_documentos
  on public.logistica_rastreamentos(numero_nfe,numero_cte,protocolo_rastreio);

alter table public.logistica_rastreamentos enable row level security;

drop policy if exists "acesso_logistica_rastreamentos"
  on public.logistica_rastreamentos;

create policy "acesso_logistica_rastreamentos"
  on public.logistica_rastreamentos
  for all to anon, authenticated
  using (true)
  with check (true);

select 'V19: fluxo logístico completo configurado.' as resultado;
