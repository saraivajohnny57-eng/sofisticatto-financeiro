-- ============================================================
-- V16.1 — HOMOLOGAÇÃO CIF BÁSICA E HISTÓRICO SEGURO
-- ============================================================

alter table public.integracao_homologacao_checklist
  add column if not exists valor_api numeric(14,2),
  add column if not exists valor_portal numeric(14,2),
  add column if not exists diferenca_valor numeric(14,2),
  add column if not exists diferenca_percentual numeric(12,4),
  add column if not exists prazo_api integer,
  add column if not exists prazo_portal integer,
  add column if not exists homologacao_cif_basica boolean not null default false,
  add column if not exists comparado_em timestamptz;

create or replace function public.listar_rodonaves_cotacoes_seguras(
  p_limite integer default 50
)
returns table (
  created_at timestamptz,
  cliente_nome text,
  cep_destino text,
  peso_total numeric,
  volumes integer,
  cubagem_total numeric,
  valor_frete numeric,
  prazo_dias integer,
  numero_cotacao text
)
language sql
security definer
set search_path = public
as $$
  select
    r.created_at,
    r.cliente_nome,
    r.cep_destino,
    r.peso_total,
    r.volumes,
    r.cubagem_total,
    r.valor_frete,
    r.prazo_dias,
    r.numero_cotacao
  from public.rodonaves_cotacoes_api r
  order by r.created_at desc
  limit greatest(1,least(coalesce(p_limite,50),200));
$$;

revoke all on function public.listar_rodonaves_cotacoes_seguras(integer) from public;
grant execute on function public.listar_rodonaves_cotacoes_seguras(integer)
  to anon, authenticated;

select 'V16.1: homologação CIF básica e histórico seguro configurados.' as resultado;
