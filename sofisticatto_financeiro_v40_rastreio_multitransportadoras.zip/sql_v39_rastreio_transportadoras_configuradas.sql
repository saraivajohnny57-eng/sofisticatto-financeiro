-- V39 — Rastreamento automático para transportadoras configuradas
-- Execute depois da V38.

-- 1) Garante endpoint de ocorrências para toda integração SSW/WebService
-- que tenha rastreamento OU coleta habilitados.
do $$
declare r record;
begin
  for r in
    select ti.convite_id, ti.transportadora_nome, ti.integracao_tipo, ti.api_versao
      from public.transportadora_integracoes ti
     where coalesce(ti.rastreamento_ativo,false)=true
        or coalesce(ti.coleta_ativa,false)=true
  loop
    -- Só registra o endpoint automático quando a ficha estiver configurada
    -- como WebService/SSW. Outros provedores continuam usando sua API própria.
    if lower(trim(coalesce(r.integracao_tipo,'')))='webservice'
       or lower(coalesce(r.api_versao,'')) like '%ssw%'
    then
      insert into public.transportadora_endpoints
        (convite_id,operacao,ambiente,metodo,formato,url,observacao)
      values
        (r.convite_id,'ocorrencias','producao','POST','json',
         'https://sofisticatto-financeiro.vercel.app/api/ssw-ocorrencias?convite_id='||r.convite_id::text,
         'Rastreio automático SSW: recebe ocorrências, cria NF não lançada previamente e atualiza até a entrega.')
      on conflict(convite_id,operacao,ambiente) do update set
        url=excluded.url,
        metodo=excluded.metodo,
        formato=excluded.formato,
        observacao=excluded.observacao,
        atualizado_em=now();
    end if;
  end loop;
end $$;

-- 2) Melhora consultas por transportadora/NF/status.
create index if not exists idx_logistica_rastreios_transportadora_nfe_status
  on public.logistica_rastreamentos(transportadora_id,numero_nfe,status);

create index if not exists idx_logistica_rastreios_transportadora_chave_status
  on public.logistica_rastreamentos(transportadora_id,chave_nfe,status);

select 'V39: rastreamento automático das transportadoras configuradas preparado.' as resultado;
