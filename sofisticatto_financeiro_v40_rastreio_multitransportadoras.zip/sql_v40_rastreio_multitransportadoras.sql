-- ============================================================
-- V40 — RASTREIO MULTITRANSPORTADORAS
-- ACCERT / TG / Rodonaves / Alfa / demais cadastradas
-- Execute depois da V39.
-- ============================================================

-- 1) Integrações SSW/WebService que já estão configuradas para coleta
-- também entram no painel de rastreamento.
update public.transportadora_integracoes
set rastreamento_ativo = true,
    atualizado_em = now(),
    observacao_status = case
      when coalesce(observacao_status,'') = '' then 'Rastreamento habilitado pela V40. Ocorrências SSW atualizam a NF automaticamente.'
      else observacao_status || ' | V40: rastreamento habilitado.'
    end
where coalesce(status_tecnico,'') <> 'suspensa'
  and (
    lower(trim(coalesce(integracao_tipo,''))) = 'webservice'
    or lower(coalesce(api_versao,'')) like '%ssw%'
  )
  and (coalesce(coleta_ativa,false)=true or coalesce(rastreamento_ativo,false)=true);

-- 2) Trigger geral: qualquer coleta válida com identificador logístico passa
-- a ter registro no painel. Antes da V40 isso era antecipado só para Rodonaves.
create or replace function public.fn_coleta_para_rastreamento()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_status_coleta text;
  v_status_rastreio text;
  v_numero_nfe text;
  v_chave_nfe text;
  v_numero_cte text;
  v_protocolo text;
begin
  v_status_coleta := lower(coalesce(new.status_api,new.status,''));

  if v_status_coleta in ('rascunho','cancelado','cancelamento_solicitado','erro') then
    return new;
  end if;

  v_numero_nfe := coalesce(
    nullif(trim(new.numero_nf),''),
    nullif(trim(new.dados->>'numero_nf'),''),
    nullif(trim(new.dados->>'numero_nfe'),'')
  );
  v_chave_nfe := coalesce(
    nullif(trim(new.chave_nfe),''),
    nullif(trim(new.dados->>'chave_nfe'),''),
    nullif(trim(new.dados->>'chave_nf'),'')
  );
  v_numero_cte := coalesce(
    nullif(trim(new.numero_cte),''),
    nullif(trim(new.dados->>'numero_cte'),'')
  );
  v_protocolo := coalesce(
    nullif(trim(new.protocolo_rastreio),''),
    nullif(trim(new.protocolo_cotacao),'')
  );

  if v_numero_nfe is null and v_chave_nfe is null and v_numero_cte is null and v_protocolo is null then
    return new;
  end if;

  v_status_rastreio := case
    when v_status_coleta in ('coletado','coletada') or new.coletado_em is not null then 'em_transito'
    else 'aguardando_coleta'
  end;

  insert into public.logistica_rastreamentos(
    sentido,parceiro_nome,transportadora_id,numero_nfe,chave_nfe,numero_cte,
    protocolo_rastreio,data_postagem,volumes,status,observacao,
    coleta_agendamento_id,origem,atualizado_em,atualizado_por
  ) values (
    'saida',coalesce(nullif(trim(new.cliente_nome),''),'Cliente'),new.transportadora_id,
    v_numero_nfe,regexp_replace(coalesce(v_chave_nfe,''),'\\D','','g'),v_numero_cte,
    v_protocolo,
    case when v_status_rastreio='em_transito'
      then coalesce(new.coletado_em::date,new.data_programada::date,current_date)
      else new.data_programada::date end,
    new.volumes,v_status_rastreio,
    'V40: rastreio criado/vinculado automaticamente a partir da coleta.',
    new.id,'coleta_agendamento',now(),'trigger_v40'
  )
  on conflict (coleta_agendamento_id)
    where coleta_agendamento_id is not null
  do update set
    parceiro_nome=excluded.parceiro_nome,
    transportadora_id=excluded.transportadora_id,
    numero_nfe=coalesce(excluded.numero_nfe,public.logistica_rastreamentos.numero_nfe),
    chave_nfe=coalesce(nullif(excluded.chave_nfe,''),public.logistica_rastreamentos.chave_nfe),
    numero_cte=coalesce(excluded.numero_cte,public.logistica_rastreamentos.numero_cte),
    protocolo_rastreio=coalesce(excluded.protocolo_rastreio,public.logistica_rastreamentos.protocolo_rastreio),
    data_postagem=coalesce(excluded.data_postagem,public.logistica_rastreamentos.data_postagem),
    volumes=coalesce(excluded.volumes,public.logistica_rastreamentos.volumes),
    status=case
      when public.logistica_rastreamentos.status <> 'aguardando_coleta'
        then public.logistica_rastreamentos.status
      else excluded.status
    end,
    atualizado_em=now();

  return new;
end;
$$;

drop trigger if exists trg_coleta_para_rastreamento on public.coleta_agendamentos;
create trigger trg_coleta_para_rastreamento
after insert or update of status,status_api,coletado_em,numero_nf,chave_nfe,numero_cte,protocolo_rastreio,transportadora_id
on public.coleta_agendamentos
for each row execute function public.fn_coleta_para_rastreamento();

-- 3) BACKFILL: traz para o rastreio as coletas antigas que já têm NF/chave/CT-e/protocolo,
-- inclusive ACCERT e TG que ficaram invisíveis nas versões anteriores.
insert into public.logistica_rastreamentos(
  sentido,parceiro_nome,transportadora_id,numero_nfe,chave_nfe,numero_cte,
  protocolo_rastreio,data_postagem,volumes,status,observacao,
  coleta_agendamento_id,origem,atualizado_em,atualizado_por
)
select
  'saida',coalesce(nullif(trim(c.cliente_nome),''),'Cliente'),c.transportadora_id,
  coalesce(nullif(trim(c.numero_nf),''),nullif(trim(c.dados->>'numero_nf'),''),nullif(trim(c.dados->>'numero_nfe'),'')),
  regexp_replace(coalesce(nullif(trim(c.chave_nfe),''),nullif(trim(c.dados->>'chave_nfe'),''),nullif(trim(c.dados->>'chave_nf'),''),''),'\\D','','g'),
  coalesce(nullif(trim(c.numero_cte),''),nullif(trim(c.dados->>'numero_cte'),'')),
  coalesce(nullif(trim(c.protocolo_rastreio),''),nullif(trim(c.protocolo_cotacao),'')),
  case
    when lower(coalesce(c.status_api,c.status,'')) in ('coletado','coletada') or c.coletado_em is not null
      then coalesce(c.coletado_em::date,c.data_programada::date,c.created_at::date)
    else c.data_programada::date
  end,
  c.volumes,
  case
    when lower(coalesce(c.status_api,c.status,'')) in ('coletado','coletada') or c.coletado_em is not null
      then 'em_transito'
    else 'aguardando_coleta'
  end,
  'Backfill V40: coleta existente incluída no painel multitransportadoras.',
  c.id,'coleta_agendamento',now(),'migracao_v40'
from public.coleta_agendamentos c
where c.transportadora_id is not null
  and lower(coalesce(c.status_api,c.status,'')) not in ('rascunho','cancelado','cancelamento_solicitado','erro')
  and (
    nullif(trim(c.numero_nf),'') is not null
    or nullif(trim(c.dados->>'numero_nf'),'') is not null
    or nullif(trim(c.dados->>'numero_nfe'),'') is not null
    or nullif(trim(c.chave_nfe),'') is not null
    or nullif(trim(c.dados->>'chave_nfe'),'') is not null
    or nullif(trim(c.numero_cte),'') is not null
    or nullif(trim(c.dados->>'numero_cte'),'') is not null
    or nullif(trim(c.protocolo_rastreio),'') is not null
    or nullif(trim(c.protocolo_cotacao),'') is not null
  )
  and not exists (
    select 1 from public.logistica_rastreamentos r
    where r.coleta_agendamento_id=c.id
  );

-- 4) Atualiza registros já existentes com dados faltantes da coleta correspondente.
update public.logistica_rastreamentos r
set numero_nfe=coalesce(r.numero_nfe,nullif(trim(c.numero_nf),''),nullif(trim(c.dados->>'numero_nf'),''),nullif(trim(c.dados->>'numero_nfe'),'')),
    chave_nfe=coalesce(r.chave_nfe,nullif(regexp_replace(coalesce(c.chave_nfe,c.dados->>'chave_nfe',c.dados->>'chave_nf',''),'\\D','','g'),'')),
    numero_cte=coalesce(r.numero_cte,nullif(trim(c.numero_cte),''),nullif(trim(c.dados->>'numero_cte'),'')),
    protocolo_rastreio=coalesce(r.protocolo_rastreio,nullif(trim(c.protocolo_rastreio),''),nullif(trim(c.protocolo_cotacao),'')),
    atualizado_em=now()
from public.coleta_agendamentos c
where r.coleta_agendamento_id=c.id;

select
  'V40 instalada: painel multitransportadoras e backfill concluídos.' as resultado,
  count(*) filter (where sentido='saida' and status not in ('entregue','recebido','cancelado')) as saidas_em_monitoramento
from public.logistica_rastreamentos;
